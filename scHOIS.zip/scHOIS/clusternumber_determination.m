function [kcalin,ksilhou,kdavies]=clusternumber_determination(dataname)

data_dir='data/'
addpath(genpath('Dependencies')); 
addpath(genpath('functions')); 
method='weighted';

 if (strcmp(dataname, 'brain'))
     load ([data_dir 'raw_data/brain']);
     data = A';
 end
  if (strcmp(dataname, 'Kolod'))
     load ([data_dir 'raw_data/Kolod']);
      data=in_X;
  end
  if (strcmp(dataname, 'Goolam'))
     load ([data_dir 'raw_data/Goolam']);
      data=A';
  end
  if (strcmp(dataname, 'Patel'))
     load ([data_dir 'raw_data/Patel']);
      data=10.^data'-1;
  end
   if (strcmp(dataname, 'Deng'))
     load ([data_dir 'raw_data/Deng']);
      data = data';
 end

  if (strcmp(dataname, 'Treulein'))
     load ([data_dir 'raw_data/Treulein']);
      data=data';
  end   
 
    if (strcmp(dataname, 'Ting'))
     load ([data_dir 'raw_data/Ting']);
      data=A';
 end   
    
   if (strcmp(dataname, 'Yan'))
     load ([data_dir 'raw_data/Yan']);
      data=10.^A'-1;
   end   
 
   if (strcmp(dataname, 'Biase'))
     load ([data_dir 'raw_data/Biase']);
      data=A';
   end   
 
   if(strcmp(dataname, 'Klein'))
     load ([data_dir 'raw_data/Klein']);
     data=A';
   end
   
      if(strcmp(dataname, 'Usoskin'))
    
     load ([data_dir 'raw_data/Usoskin']);
     data=in_X;
     method='complete';
   
   end

    stddata=std(data);
    [sstd,sind]=sort(-stddata);   

for t = 1:5
    
clustTreeEuc = linkage(data(:,sind(1:100*t)),method,'correlation');   
   for k=2:10
         cnew(:,k-1) = cluster(clustTreeEuc,'MaxClust',k); 
   end
   
EVA= evalclusters(data(:,sind(1:100*t)),cnew,'CalinskiHarabasz');
kcalin(t)=EVA.OptimalK;


EVA= evalclusters(data(:,sind(1:t)),cnew,'Silhouette');
ksilhou(t)=EVA.OptimalK;

EVA= evalclusters(data(:,sind(1:t)),cnew,'DaviesBouldin');
kdavies(t)=EVA.OptimalK;



% EVA= evalclusters(data(:,sind(1:1950+10*t)),'linkage','CalinskiHarabasz','KLIST',[2:10]);
% kcalin(t)=EVA.OptimalK;
% 
% EVA= evalclusters(data(:,sind(1:1950+10*t)),'linkage','Silhouette','KLIST',[2:10]);
% ksilhou(t)=EVA.OptimalK;
% 
% EVA= evalclusters(data(:,sind(1:1950+10*t)),'linkage','DaviesBouldin','KLIST',[2:10]);
% kdavies(t)=EVA.OptimalK;
% 
% EVA= evalclusters(data(:,sind(1:1950+10*t)),'linkage','GAP','KLIST',[2:10]);
% kgap(t)=EVA.OptimalK;

end