function Impute_opt(dataname,n)
%clear;  clc;
tic

data_dir='data/'
addpath(genpath('Dependencies')); 
addpath(genpath('functions')); 

  
%% Import data
if(strcmp(dataname, 'Biase'))
     load ([data_dir 'raw_data/Biase']);
    data=A';
end
if (strcmp(dataname, 'Deng'))
    load ([data_dir 'raw_data/Deng']);
      data=A';
end
if (strcmp(dataname, 'Goolam'))
    load ([data_dir 'raw_data/Goolam']);
      data=A';
end
 if (strcmp(dataname, 'brain'))
     load ([data_dir 'raw_data/brain']);
     data=A';
     
 end
  if (strcmp(dataname, 'Kolod'))
     load ([data_dir 'raw_data/Kolod']);
      data=10.^in_X-1;
  end
  if (strcmp(dataname, 'Pollen'))
     load ([data_dir 'raw_data/Pollen']);
      data=10.^in_X-1;
  end
  if (strcmp(dataname, 'Usoskin'))
     load ([data_dir 'raw_data/Usoskin']);
      data=10.^in_X-1;
 end

  if (strcmp(dataname, 'Klein'))
     load ([data_dir 'raw_data/Klein']);
      data=A';
 end   
    
   if (strcmp(dataname, 'Patel'))
     load ([data_dir 'raw_data/Patel']);
      data=floor((10.^data)');
   end   
 
   if (strcmp(dataname, 'Ting'))
     load ([data_dir 'raw_data/Ting']);
      data=A';
   end   
 
   if(strcmp(dataname, 'Treulein'))
     load ([data_dir 'raw_data/Treulein']);
     data=A';
   end
   
   if(strcmp(dataname,'Yan'))
       load ([data_dir 'raw_data/Yan']);
       data = A';
   end
   
   if(strcmp(dataname,'Zeisel'))
       load ([data_dir 'raw_data/Zeisel']);
       data = A';
   end

   if(strcmp(dataname,'Manno'))
       load ([data_dir 'raw_data/Manno']);
      
   end
     if(strcmp(dataname,'Baronh'))
       load ([data_dir 'raw_data/Baronh']);
      
   end
 if(strcmp(dataname,'Baronm'))
       load ([data_dir 'raw_data/Baronm']);
      
 end
 if(strcmp(dataname,'Marques'))
       load ([data_dir 'raw_data/Marques']);
      
   end
%% CALL mfmc
[data_recovered,~,data_recovered_raw, gene_names]=mfmc(data,'dataname',dataname,'fnumber',n);%,'gene_names',gene_names,'gene_ids', gene_ids,'pro_dir',pro_dir);

%% Save results
mkdir(['RecoveredMatrices/' dataname '_imputed']); 
save(['RecoveredMatrices/' dataname '_imputed/rec_mf' num2str(n) '.mat'],'data_recovered') 
time_taken=toc 



