function [ARI,NMI,des_ratio,optrank]=rank_determination(dataname)

data_dir=['RecoveredMatrices/' dataname '_imputed/']; 
data_dir1=['data/'];
load ([data_dir1 'raw_data/' dataname]);
addpath(genpath('Dependencies')); 
addpath(genpath('functions')); 
%true_labs=labels;
i0=49;
switch dataname
    case 'Kolod'
        nn = 3;
    case 'Pollen'
        nn = 11;
    case 'Usoskin'
        nn = 4;
    case 'Biase'
        nn = 3;
        true_labs=labels;
        i0=48;
    case 'Deng'
        nn=10;
        true_labs=labels;
    case 'Goolam'
        nn=5;
        true_labs=labels;
    case 'brain'
        nn = 8;
        true_labs=label;
    case 'Klein'
        nn = 4;
        true_labs=labels;
     case 'Patel'
        nn = 5;
        true_labs=labels;
    case 'Ting'
        nn = 7;
        true_labs=labels;
     case 'Treulein'
        nn = 5;
        true_labs=labels;
   %    load ([data_dir1 'raw_data/data_69405']);
     case 'Yan'
        nn = 7;
        true_labs=labels;
     case 'Zeisel'
        nn = 9;
        true_labs=labels;
    case 'Manno'
        nn=56;
        true_labs=labels;
           case 'Baronh'
        nn=14;
        true_labs=labels;
          case 'Baronm'
        nn=13;
        true_labs=labels;
    case 'Marques'
        nn=13;
        true_labs=labels;
       
end


for i=1:i0
    i
    load([data_dir 'rec_mf' num2str(i+1)]);
      stddata=std(data_recovered);
    [sstd,sind]=sort(-stddata);
    num_gene=size(data_recovered,2);
    A = data_recovered(:,sind(1:100));
    Y=pdist(A,'correlation');
    Z=linkage(Y,'weighted');
    T=cluster(Z,nn);
    stddata=std(data_recovered);
    [sstd,sind]=sort(-stddata);
   for k=1:100
        [p,tbl]=anova1(data_recovered(:,sind(k)),T,'off');
        des_ratio(i,k)=tbl{2,2}/tbl{4,2};
    end  
    ARI(i)=adjrand(T,true_labs);
    NMI(i)=Cal_NMI(T,true_labs);
end
%%%%%%%%%%%%1
%rank_val=sum(des_ratio,2);
%optrank=find(rank_val==max(rank_val))+1;

%%%%%%%%%%%%2
 dif_ratio=des_ratio(2:end,:)-des_ratio(1:end-1,:);
 sign_difratio=(dif_ratio>=0);
 optrank=find(sum(sign_difratio')==max(sum(sign_difratio')))+1;